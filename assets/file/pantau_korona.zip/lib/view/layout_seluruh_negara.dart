import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:update_corona/model/model_data_covid.dart';
import 'package:http/http.dart' as http;
import 'package:update_corona/view/layout_detail_negara.dart';

class LayoutSeluruhNegara extends StatelessWidget{
  final List<ModelDataCovid> listData;

  LayoutSeluruhNegara({Key key, this.listData}) : super(key: key);
  final NumberFormat number = NumberFormat("#,###");
  

  @override
  Widget build(BuildContext context) {
    print("semua negara");
    final List<ImageProvider> listGambar = [];
    return ListView(
      children: [
        
        listData == null?Center(child: CircularProgressIndicator(),)
        :Container(
          child: Center(
            child: Wrap(
              children: List.generate(listData.length, (index) => InkWell(
                child: Padding(
                  padding: const EdgeInsets.all(2),
                  child: Chip(
                    backgroundColor: Color(0xff3D5B8F),
                    label: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(listData[index].country,
                          style: TextStyle(
                            color: Colors.white
                          ),
                        ),
                        Text(number.format(listData[index].cases).toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold
                          ),
                        ),
                        
                      ],
                    ),
                    avatar: Hero(
                      tag: "hero$index",
                      child: CachedNetworkImage(
                        placeholder: (context, url) => CircularProgressIndicator(),
                        imageUrl: listData[index].countryInfo.flag,
                        errorWidget: (context, url, error) => Icon(Icons.error),
                        imageBuilder: (context, imageProvider){
                          listGambar.add(imageProvider);
                          return Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: imageProvider
                              )
                            ),
                          );
                        }
                      ),
                    ),
                    
                  ),
                ),
                onTap: (){

                  Navigator.push(
                    context, PageRouteBuilder( 
                      transitionDuration: Duration(seconds: 1),pageBuilder: (
                        context, animation, secondaryAnimation
                      ) => LayoutDetailNegara(
                        hero: "hero$index",dataCovid: listData[index],gambar: listGambar[index],
                      ),
                    )
                  );
                },
              )),
            ),
          ),
        )
      ],
    );
  }

  
  
}