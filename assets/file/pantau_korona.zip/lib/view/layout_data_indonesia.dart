import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:share/share.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';
import 'package:update_corona/model/model_data_indonesia.dart';
import 'package:path/path.dart';
import 'package:http/http.dart' as http;

class LayoutDataIndonesia extends StatelessWidget{
  final ModelDataIndonesia dataIndonesia;

  LayoutDataIndonesia({Key key, this.dataIndonesia}) : super(key: key);
  final _formatNilai = NumberFormat("#,###","en_US");

  String _waktu(int waktu){
    final date = DateTime.fromMillisecondsSinceEpoch(waktu);
    return DateFormat.yMMMd().format(date).toString();
  }

  Future<Database> databaseasy()async=> openDatabase(
     join(await getDatabasesPath(),'coba.db'),
     onCreate: (db, version) => db.execute("create table nama (in integer primary key,nama text)"),
    );

  @override
  Widget build(BuildContext context) {

    return dataIndonesia == null?Center(child: CircularProgressIndicator(),)
    :Scaffold(
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.share),
        onPressed: () {

          String pesan = '''
            \nProbus System
            \nkawal covid 19
            \n${_waktu(dataIndonesia.updated)}
            \nINDONESIA
            \nTotal Kasus :\n${_formatNilai.format(dataIndonesia.cases)}
            \nTootal Meniggal :\n${_formatNilai.format(dataIndonesia.deaths)}
            \nSembuh :\n${_formatNilai.format(dataIndonesia.recovered)}
            \nKasus Hari Ini :\n${_formatNilai.format(dataIndonesia.todayCases)}
            \nMeninggal Hari Ini :\n${_formatNilai.format(dataIndonesia.todayDeaths)}
          ''';

          Share.share(pesan);
        },
      ),
      body: Container(
        child: ListView(
          children: [
            Text("Kawal Covid 19".toUpperCase(),textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700
              ),
            ),
            Text(_waktu(dataIndonesia.updated),textAlign: TextAlign.center,),
            Container(
              child: Image.network(dataIndonesia.countryInfo.flag),
            ),
            Container(
              alignment: Alignment.center,
              padding: EdgeInsets.all(8),
              child: Text(dataIndonesia.country,style: TextStyle(fontSize: 32,fontWeight: FontWeight.w700),)
            ),
            Center(
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                    _infoData("total kasus", _formatNilai.format(dataIndonesia.cases).toString()),
                    _infoData("total meninggal", _formatNilai.format(dataIndonesia.deaths).toString()),
                    _infoData("sembuh", _formatNilai.format(dataIndonesia.recovered).toString()),
                    _infoData("aktif", _formatNilai.format(dataIndonesia.active).toString()),
                    _infoData("kasus hari ini", _formatNilai.format(dataIndonesia.todayCases).toString()),
                    _infoData("meninggal hari ini", _formatNilai.format(dataIndonesia.todayDeaths).toString()),
                    _infoData("jumblah tes", _formatNilai.format(dataIndonesia.tests).toString())
                ],
              ),
            )
          ],
        )
      ),
    );
  }

  

  Widget _infoData(String nama,String data){
    return Container(
      padding: EdgeInsets.all(8),
      width: 150,
      height: 150,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xffD5EFF6),
        )
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text("$nama".toUpperCase(),),
          Text(data,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700
            ),        
          )
        ],
      ),
    );
  }
}