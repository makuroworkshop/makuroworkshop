import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:update_corona/model/model_data_covid.dart';

class LayoutDetailNegara extends StatelessWidget{
  final String hero;
  final ModelDataCovid dataCovid;
  final ImageProvider gambar;
  final _formatNilai = NumberFormat("#,###","en_US");

  LayoutDetailNegara({Key key, this.hero, this.dataCovid, this.gambar}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: ListView(
            children: [
              Hero(
                tag: hero,
                child: Container(
                  width: double.infinity,
                  height: 200,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: gambar
                    )
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(8),
                alignment: Alignment.center,
                child: Text(dataCovid.country,
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w700
                  ),
                ),
              ),
              Center(
                  child: Wrap(
                    children: [
                        _infoData("total kasus", _formatNilai.format(dataCovid.cases).toString()),
                        _infoData("total meninggal",_formatNilai.format(dataCovid.deaths).toString()),
                        _infoData("sembuh", _formatNilai.format(dataCovid.recovered).toString()),
                        _infoData("aktif", _formatNilai.format(dataCovid.active).toString()),
                        _infoData("kasus hari ini", _formatNilai.format(dataCovid.todayCases).toString()),
                        _infoData("meninggal hari ini", _formatNilai.format(dataCovid.todayDeaths).toString()),
                        _infoData("jumblah tes", _formatNilai.format(dataCovid.tests).toString())
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

   Widget _infoData(String nama,String data){
    return Container(
      padding: EdgeInsets.all(8),
      width: 150,
      height: 150,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xffD5EFF6),
        )
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text("$nama".toUpperCase(),),
          Text(data,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700
            ),        
          )
        ],
      ),
    );
  }
}