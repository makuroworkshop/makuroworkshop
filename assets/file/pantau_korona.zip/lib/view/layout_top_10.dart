import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:update_corona/model/model_data_covid.dart';
import 'package:http/http.dart' as http;

class LayoutTop10 extends StatelessWidget{

  final List<ModelDataCovid> listDataCovid;
  final _formatNilai = NumberFormat("#,###","en_US");

  LayoutTop10({Key key, this.listDataCovid}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return listDataCovid == null?Center(child: CircularProgressIndicator(),)
    :Container(
      child: ListView(
        children: [
          Text("Top 10 Country",textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  CachedNetworkImage(
                    placeholder: (context, url) => Center(child: CircularProgressIndicator(),),
                    imageUrl: listDataCovid[0].countryInfo.flag,
                  ),
                  Text(listDataCovid[0].country,
                    style: TextStyle(
                      fontSize: 64,
                      fontWeight: FontWeight.w700
                    ),
                  ),
                  Center(
                    child: Wrap(
                      children: [
                          _infoData("total kasus", _formatNilai.format(listDataCovid[0].cases).toString()),
                          _infoData("total meninggal",_formatNilai.format(listDataCovid[0].deaths).toString()),
                          _infoData("sembuh", _formatNilai.format(listDataCovid[0].recovered).toString()),
                          _infoData("aktif", _formatNilai.format(listDataCovid[0].active).toString()),
                          _infoData("kasus hari ini", _formatNilai.format(listDataCovid[0].todayCases).toString()),
                          _infoData("meninggal hari ini", _formatNilai.format(listDataCovid[0].todayDeaths).toString()),
                          _infoData("jumblah tes", _formatNilai.format(listDataCovid[0].tests).toString())
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Column(
            children: List.generate(listDataCovid.take(10).length, (index) => Container(
              child: index == 0?Visibility(child: SizedBox.shrink(),visible: false,)
              :ListTile(
                leading: Image.network(listDataCovid[index].countryInfo.flag,width: 50,height: 25,),
                title: Card(
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        alignment: Alignment.centerLeft,
                        child: Text(listDataCovid[index].country,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold
                          ),
                        )
                      ),
                      Wrap(
                        children: [
                          _infoData2("total kasus", _formatNilai?.format(listDataCovid[index]?.cases)?.toString()),
                          _infoData2("total meninggal",_formatNilai.format(listDataCovid[index].deaths).toString()),
                          _infoData2("sembuh", _formatNilai?.format(listDataCovid[index]?.recovered??0)?.toString()),
                          _infoData2("aktif", _formatNilai.format(listDataCovid[index].active).toString()),
                          _infoData2("kasus hari ini", _formatNilai.format(listDataCovid[index].todayCases).toString()),
                          _infoData2("meninggal hari ini", _formatNilai.format(listDataCovid[index].todayDeaths).toString()),
                          _infoData2("jumblah tes", _formatNilai.format(listDataCovid[index].tests).toString())
                        ],
                      )
                    ],
                  ),
                )
              ),
            )),
          )
        ],
      ),
    );
  }

  Widget _infoData2(String nama,String text){
    return Container(
      padding: EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(nama,textAlign: TextAlign.center,),
          Text(text,textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }

  Widget _infoData(String nama,String data){
    return Container(
      padding: EdgeInsets.all(8),
      width: 150,
      height: 150,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xffD5EFF6),
        )
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text("$nama".toUpperCase(),),
          Text(data,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700
            ),        
          )
        ],
      ),
    );
  }
}